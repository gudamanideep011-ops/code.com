import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const searchCodingQuery = async (query: string): Promise<string> => {
  try {
    const model = "gemini-2.5-flash";
    const systemInstruction = `
      You are code.in, an advanced AI programming assistant.
      Your interface is futuristic and minimal.
      Provide concise, high-quality technical answers.
      If the user asks for code, provide it in standard markdown code blocks.
      Keep explanations brief and to the point unless asked for details.
      Format with Markdown.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: query,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    return response.text || "No response generated.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Error connecting to the code.in network. Please try again.";
  }
};
