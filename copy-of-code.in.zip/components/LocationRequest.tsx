import React, { useState } from 'react';
import { MapPin, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';

interface LocationRequestProps {
  onLocationSaved: () => void;
}

const LocationRequest: React.FC<LocationRequestProps> = ({ onLocationSaved }) => {
  const [status, setStatus] = useState<'idle' | 'loading' | 'saving' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const handleAllowLocation = () => {
    setStatus('loading');
    
    if (!navigator.geolocation) {
      setErrorMsg("Geolocation is not supported by your browser.");
      setStatus('error');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        // Mock saving to server
        setStatus('saving');
        const coords = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        
        console.log("Saving location to server:", coords);
        
        // Simulate network delay for "Saving..."
        setTimeout(() => {
          setStatus('success');
          // Delay before moving to next screen
          setTimeout(() => {
            onLocationSaved();
          }, 1500);
        }, 1500);
      },
      (error) => {
        setErrorMsg("Unable to retrieve location. Access denied.");
        setStatus('error');
        console.error(error);
      }
    );
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 animate-fade-in">
      <div className="bg-glass backdrop-blur-xl border border-glassBorder p-8 rounded-2xl w-full max-w-md shadow-2xl text-center">
        <div className="mb-6 flex justify-center">
          <div className="w-20 h-20 rounded-full bg-blue-500/10 flex items-center justify-center border border-blue-500/30">
            {status === 'loading' || status === 'saving' ? (
              <Loader2 size={32} className="text-blue-400 animate-spin" />
            ) : status === 'success' ? (
              <CheckCircle2 size={32} className="text-green-400" />
            ) : status === 'error' ? (
               <AlertCircle size={32} className="text-red-400" />
            ) : (
              <MapPin size={32} className="text-blue-400" />
            )}
          </div>
        </div>

        <h2 className="text-2xl font-bold text-white mb-2">Protocol Requirement</h2>
        <p className="text-gray-400 mb-8 text-sm">
          Security protocols require geolocation verification. 
          Your coordinates will be encrypted and stored in our secure server node.
        </p>

        {status === 'error' && (
             <div className="mb-6 p-3 bg-red-500/10 border border-red-500/30 rounded text-red-300 text-sm">
                 {errorMsg}
             </div>
        )}

        <button
          onClick={handleAllowLocation}
          disabled={status === 'loading' || status === 'saving' || status === 'success'}
          className={`
            w-full py-3 rounded-lg font-bold transition-all duration-300 flex items-center justify-center gap-2
            ${status === 'success' 
              ? 'bg-green-500/20 text-green-400 border border-green-500/50' 
              : 'bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_15px_rgba(37,99,235,0.5)]'}
            disabled:opacity-50 disabled:cursor-not-allowed
          `}
        >
          {status === 'loading' ? 'Locating...' : 
           status === 'saving' ? 'Uploading to Server...' :
           status === 'success' ? 'Verified' :
           'ALLOW LOCATION ACCESS'}
        </button>
        
        {status === 'idle' && (
            <p className="mt-4 text-xs text-gray-600">
                By clicking allow, you consent to data synchronization.
            </p>
        )}
      </div>
    </div>
  );
};

export default LocationRequest;
