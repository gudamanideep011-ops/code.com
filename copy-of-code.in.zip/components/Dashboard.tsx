import React, { useState, useRef, useEffect } from 'react';
import { User } from '../types';
import { Search, Code, Cpu, Sparkles, User as UserIcon, LogOut, ChevronRight } from 'lucide-react';
import { searchCodingQuery } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';

interface DashboardProps {
  user: User;
  onLogout: () => void;
}

const SUGGESTIONS = [
  "Python Algorithms",
  "React Hooks",
  "Rust vs Go",
  "CSS Grid Layout",
  "Machine Learning Basics",
  "Docker Containerization"
];

const Dashboard: React.FC<DashboardProps> = ({ user, onLogout }) => {
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  const handleSearch = async (e?: React.FormEvent, customQuery?: string) => {
    if (e) e.preventDefault();
    const q = customQuery || query;
    if (!q.trim()) return;

    setIsSearching(true);
    setResult(null); // Clear previous
    setQuery(q);

    // Visual scroll to results area
    setTimeout(() => {
        resultsRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);

    const response = await searchCodingQuery(q);
    setResult(response);
    setIsSearching(false);
  };

  return (
    <div className="relative min-h-screen flex flex-col text-white">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 px-6 py-4 flex justify-between items-center bg-black/20 backdrop-blur-md border-b border-white/5">
        <div className="w-1/3 text-xs text-gray-500 font-mono hidden md:block">
           SYSTEM: ONLINE <span className="text-green-500 ml-2">●</span>
        </div>

        <div className="w-1/3 flex justify-center">
          <div className="text-2xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-500 flex items-center gap-2 cursor-pointer select-none hover:scale-105 transition-transform">
            <Code className="text-neon" size={24} />
            <span>code.in</span>
          </div>
        </div>

        <div className="w-1/3 flex justify-end items-center gap-4">
          <div className="flex items-center gap-3 bg-white/5 px-4 py-2 rounded-full border border-white/10">
            <div className="w-2 h-2 rounded-full bg-neon animate-pulse"></div>
            <span className="font-mono text-sm hidden sm:inline">{user.username}</span>
            <UserIcon size={16} className="text-gray-400" />
          </div>
          <button 
            onClick={onLogout}
            className="p-2 hover:bg-red-500/20 rounded-full transition-colors text-gray-400 hover:text-red-400"
            title="Disconnect"
          >
            <LogOut size={20} />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 pt-24 pb-12 w-full max-w-5xl mx-auto z-10">
        
        {/* Hero Section */}
        <div className={`transition-all duration-700 w-full flex flex-col items-center ${result ? 'mt-10 mb-8' : 'mt-[15vh]'}`}>
          <div className="mb-8 relative">
            <Cpu size={64} className="text-neon/80 animate-pulse-slow absolute -top-4 -left-12 opacity-50 blur-sm" />
            <h1 className="text-4xl md:text-6xl font-bold text-center bg-clip-text text-transparent bg-gradient-to-b from-white via-gray-200 to-gray-600">
              What will you build?
            </h1>
          </div>

          {/* Search Bar */}
          <form onSubmit={(e) => handleSearch(e)} className="w-full max-w-2xl relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-neon rounded-xl blur opacity-25 group-hover:opacity-50 transition duration-500"></div>
            <div className="relative bg-black/60 backdrop-blur-xl border border-white/10 rounded-xl p-2 flex items-center shadow-2xl">
              <Search className="ml-4 text-gray-400" size={24} />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search libraries, syntax, or concepts..."
                className="w-full bg-transparent border-none text-white text-lg px-4 py-3 focus:outline-none placeholder-gray-500 font-light"
              />
              <button 
                type="submit"
                disabled={isSearching}
                className="bg-white/10 hover:bg-neon hover:text-black text-white px-6 py-2 rounded-lg font-medium transition-all duration-300 disabled:opacity-50"
              >
                {isSearching ? <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin"/> : <ChevronRight />}
              </button>
            </div>
          </form>

          {/* Suggestions */}
          {!result && (
            <div className="mt-8 flex flex-wrap justify-center gap-3 animate-fade-in-up">
              {SUGGESTIONS.map((tag) => (
                <button
                  key={tag}
                  onClick={() => handleSearch(undefined, tag)}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/5 hover:border-neon/50 rounded-full text-sm text-gray-400 hover:text-neon transition-all duration-300 backdrop-blur-sm"
                >
                  {tag}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Results Section */}
        { (isSearching || result) && (
          <div ref={resultsRef} className="w-full max-w-4xl mt-8 animate-fade-in-up">
            <div className="bg-black/40 backdrop-blur-md border border-white/10 rounded-2xl p-1 overflow-hidden shadow-2xl">
              <div className="bg-white/5 px-4 py-2 flex items-center gap-2 border-b border-white/5">
                <Sparkles size={16} className="text-yellow-400" />
                <span className="text-xs font-mono text-gray-400 uppercase tracking-widest">
                    {isSearching ? 'Processing Query...' : 'Intelligence Response'}
                </span>
              </div>
              
              <div className="p-6 md:p-8 min-h-[200px]">
                {isSearching ? (
                  <div className="flex flex-col items-center justify-center h-40 space-y-4">
                     <div className="flex space-x-2">
                        <div className="w-3 h-3 bg-neon rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                        <div className="w-3 h-3 bg-neon rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                        <div className="w-3 h-3 bg-neon rounded-full animate-bounce"></div>
                     </div>
                     <p className="text-sm text-gray-500 font-mono animate-pulse">Accessing Neural Database...</p>
                  </div>
                ) : (
                  <div className="prose prose-invert prose-pre:bg-black/50 prose-pre:border prose-pre:border-white/10 max-w-none">
                    <ReactMarkdown>{result || ''}</ReactMarkdown>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="w-full py-6 text-center text-xs text-gray-600 font-mono border-t border-white/5 bg-black/20 backdrop-blur-sm">
        code.in system v2.0.4 &copy; {new Date().getFullYear()} // ALL RIGHTS RESERVED
      </footer>
    </div>
  );
};

export default Dashboard;
