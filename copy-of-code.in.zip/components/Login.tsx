import React, { useState } from 'react';
import { User } from '../types';
import { Terminal, ArrowRight } from 'lucide-react';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      onLogin({ username, isLoggedIn: true });
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 animate-fade-in">
      <div className="bg-glass backdrop-blur-xl border border-glassBorder p-8 rounded-2xl w-full max-w-md shadow-2xl transform transition-all duration-500 hover:scale-[1.01]">
        <div className="flex items-center justify-center mb-8 text-neon">
          <Terminal size={48} className="animate-pulse-slow" />
        </div>
        <h1 className="text-3xl font-bold text-center mb-2 font-mono tracking-tighter text-white">code.in</h1>
        <p className="text-gray-400 text-center mb-8 text-sm">Initialize sequence to continue</p>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="relative group">
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter Identity"
              className="w-full bg-black/30 border border-gray-700 text-white px-4 py-3 rounded-lg focus:outline-none focus:border-neon focus:ring-1 focus:ring-neon transition-all font-mono placeholder-gray-600"
              autoFocus
            />
          </div>
          
          <button
            type="submit"
            className="w-full bg-neon text-black font-bold py-3 rounded-lg hover:bg-white hover:shadow-[0_0_20px_rgba(0,243,255,0.5)] transition-all duration-300 flex items-center justify-center gap-2 group"
          >
            <span>INITIALIZE</span>
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
