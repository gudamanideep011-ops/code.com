export interface User {
  username: string;
  isLoggedIn: boolean;
}

export interface Coordinates {
  latitude: number;
  longitude: number;
}

export interface SearchResult {
  text: string;
  timestamp: number;
}

export enum AppState {
  LOGIN,
  LOCATION_REQUEST,
  DASHBOARD
}
