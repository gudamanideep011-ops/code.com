import React, { useState } from 'react';
import { User, AppState } from './types';
import Login from './components/Login';
import LocationRequest from './components/LocationRequest';
import Dashboard from './components/Dashboard';
import AnimatedBackground from './components/AnimatedBackground';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.LOGIN);
  const [user, setUser] = useState<User | null>(null);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    setAppState(AppState.LOCATION_REQUEST);
  };

  const handleLocationSaved = () => {
    setAppState(AppState.DASHBOARD);
  };

  const handleLogout = () => {
    setUser(null);
    setAppState(AppState.LOGIN);
  };

  return (
    <div className="text-white min-h-screen font-sans">
      <AnimatedBackground />
      
      {appState === AppState.LOGIN && (
        <Login onLogin={handleLogin} />
      )}

      {appState === AppState.LOCATION_REQUEST && (
        <LocationRequest onLocationSaved={handleLocationSaved} />
      )}

      {appState === AppState.DASHBOARD && user && (
        <Dashboard user={user} onLogout={handleLogout} />
      )}
    </div>
  );
};

export default App;
